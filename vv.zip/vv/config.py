WIDTH, HEIGHT = 1080, 1920
FPS = 30
SEC_PER = 4.0
BG = "black"

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
AUDIO_EXTS = {".mp3", ".wav"}