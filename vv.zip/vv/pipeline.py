from __future__ import annotations
from pathlib import Path
from collections.abc import Iterable, Callable

import math
import numpy as np
from moviepy import ImageClip, CompositeVideoClip, concatenate_videoclips
from moviepy.video.fx import CrossFadeIn

from .image import fit_to_canvas
from .audio import prepare_audio
from .config import WIDTH, HEIGHT, BG, IMAGE_EXTS

from PIL import Image, ImageOps, ImageFilter

PathLike = str | Path
CropOffsets = dict[str, tuple[float, float]]
ProgressCB = Callable[[int, int], None] | None


def _collect_images(images: PathLike | Iterable[PathLike]) -> list[Path]:
    """Собрать все картинки из аргументов: файлы/папки."""
    if isinstance(images, (str, Path)):
        p = Path(images)
        if p.is_dir():
            return sorted(
                x for x in p.iterdir()
                if x.suffix.lower() in IMAGE_EXTS
            )
        elif p.is_file():
            return [p]
        else:
            raise FileNotFoundError(f"Путь не найден: {p}")
    else:
        return [Path(x) for x in images]


def build_video(
    images: PathLike | Iterable[PathLike],
    out: PathLike,
    sec_per: float,
    fps: int,
    size: tuple[int, int] = (WIDTH, HEIGHT),
    bg: str = BG,
    audio: PathLike | None = None,
    transitions: bool = False,
    motion: str = "none",           # "none" | "zoom" | "kenburns"
    audio_adjust: str = "trim",
    progress_cb: ProgressCB = None,
    total_duration: float | None = None,
    fit_mode: str = "fit",
    fancy_bg: bool = True,
    crop_offsets: CropOffsets | None = None,
) -> str:
    """Основной пайплайн: картинки -> вертикальное видео (+ опционально аудио)."""

    # --- сбор картинок ---
    img_paths = _collect_images(images)
    if not img_paths:
        raise ValueError("Нет входных изображений")

    n = len(img_paths)

    # --- нормализация режимов ---
    fit_mode = fit_mode.lower()
    audio_adjust = audio_adjust.lower()
    motion = motion.lower()

    # --- валидация аргументов ---
    if fps <= 0:
        raise ValueError("fps должен быть > 0")

    if size[0] <= 0 or size[1] <= 0:
        raise ValueError("size должен быть положительными числами (width, height)")

    if total_duration is not None:
        if total_duration <= 0:
            raise ValueError("total_duration должна быть > 0")
        # sec_per дальше пересчитаем из total_duration, так что его значение сейчас не важно
    else:
        if sec_per <= 0:
            raise ValueError("sec_per должна быть > 0, если total_duration не задана")

    if fit_mode not in {"fit", "cover"}:
        raise ValueError(f"Неизвестный режим fit_mode={fit_mode!r}")

    if audio_adjust not in {"trim", "loop"}:
        raise ValueError(f"Неизвестный режим audio_adjust={audio_adjust!r}")

    allowed_motion = {"none", "zoom", "kenburns"}
    if motion not in allowed_motion:
        raise ValueError(
            f"motion должен быть 'none', 'zoom' или 'kenburns', а не {motion!r}"
        )

    # --- вычисление sec_per с учётом total_duration ---
    if total_duration is not None:
        sec_per = float(total_duration) / n

    sec_per = float(sec_per)  # окончательно приводим к float
    W, H = size

    # старт прогресса
    if progress_cb:
        progress_cb(0, len(img_paths))

    clips: list[ImageClip] = []

    # ---- основной цикл по кадрам ----
    for idx, p in enumerate(img_paths, 1):
        # --- режим Ken Burns ---
        if motion == "kenburns":
            # открываем оригинал
            im = Image.open(p).convert("RGB")
            im = ImageOps.exif_transpose(im)

            W_target, H_target = W, H

            if fit_mode == "cover":
                # ===== Ken Burns для cover =====
                scale_base = max(W_target / im.width, H_target / im.height)
                grow = 1.06
                k = scale_base * grow

                new_w, new_h = int(im.width * k), int(im.height * k)
                im_resized = im.resize((new_w, new_h), Image.LANCZOS)

                frame_arr = np.array(im_resized)
                base_clip = ImageClip(frame_arr).with_duration(sec_per)

                max_dx = max(0, new_w - W_target)
                max_dy = max(0, new_h - H_target)

                if max_dx == 0 and max_dy == 0:
                    # fallback: просто мягкий zoom
                    strength = 0.03

                    def zoom_factor(t: float) -> float:
                        return 1.0 + strength * (t / max(sec_per, 1e-6))

                    clip = base_clip.resized(new_size=zoom_factor)

                else:
                    travel = 0.35  # проходим только часть доступного пути

                    cx = max_dx / 2.0
                    cy = max_dy / 2.0

                    pattern = idx % 4

                    if pattern == 0:
                        # диагональ слева-сверху к центру
                        start_x, end_x = 0.0, max_dx * travel
                        start_y, end_y = 0.0, max_dy * travel
                    elif pattern == 1:
                        # диагональ справа-снизу к центру
                        start_x, end_x = max_dx, max_dx * (1.0 - travel)
                        start_y, end_y = max_dy, max_dy * (1.0 - travel)
                    elif pattern == 2:
                        # горизонталь вокруг центра
                        start_x = max_dx * (0.5 - travel / 2.0)
                        end_x   = max_dx * (0.5 + travel / 2.0)
                        start_y = end_y = cy
                    else:
                        # вертикаль вокруг центра
                        start_y = max_dy * (0.5 - travel / 2.0)
                        end_y   = max_dy * (0.5 + travel / 2.0)
                        start_x = end_x = cx

                    def alpha(t: float) -> float:
                        if sec_per <= 0:
                            return 0.0
                        x = min(max(t / sec_per, 0.0), 1.0)
                        # плавное ease-in-out
                        return 0.5 - 0.5 * math.cos(math.pi * x)

                    def x1_func(t: float) -> float:
                        a = alpha(t)
                        return start_x + (end_x - start_x) * a

                    def y1_func(t: float) -> float:
                        a = alpha(t)
                        return start_y + (end_y - start_y) * a

                    # лёгкий zoom-in / zoom-out сверху
                    if pattern in (0, 2):
                        scale_start, scale_end = 1.0, 1.03
                    else:
                        scale_start, scale_end = 1.03, 1.0

                    def scale_func(t: float) -> float:
                        a = alpha(t)
                        return scale_start + (scale_end - scale_start) * a

                    def pos_func(t: float) -> tuple[float, float]:
                        x1 = x1_func(t)
                        y1 = y1_func(t)
                        # двигаем большой кадр так, чтобы окно W×H смотрело в нужную область
                        return -x1, -y1

                    moving_clip = (
                        base_clip
                        .resized(new_size=scale_func)
                        .with_position(pos_func)
                    )

                    clip = CompositeVideoClip(
                        [moving_clip],
                        size=(W_target, H_target),
                    ).with_duration(sec_per)

            else:
                # ===== Ken Burns для fit с аккуратным overscan =====
                # 1) статичный blur-фон под размер кадра
                bg_im = ImageOps.fit(im, (W_target, H_target), Image.LANCZOS)
                bg_im = bg_im.filter(ImageFilter.GaussianBlur(radius=30))
                bg_clip = ImageClip(np.array(bg_im)).with_duration(sec_per)

                # 2) базовый fit
                s_fit = min(W_target / im.width, H_target / im.height)
                w_fit = im.width * s_fit
                h_fit = im.height * s_fit

                overscan_frac = 0.08  # ~8% запаса

                # какие оси упёрлись в рамку?
                hug_x = abs(w_fit - W_target) < 1e-3
                hug_y = abs(h_fit - H_target) < 1e-3

                # overscan только если хоть по одной оси картинка ровно впритык
                if hug_x or hug_y:
                    k = 1.0 + overscan_frac
                else:
                    k = 1.0

                # один общий коэффициент — не ломаем аспект-ratio
                fg_w = int(im.width * s_fit * k)
                fg_h = int(im.height * s_fit * k)

                fg_im = im.resize((fg_w, fg_h), Image.LANCZOS)
                fg_clip = ImageClip(np.array(fg_im)).with_duration(sec_per)

                # диапазоны позиций (top-left) так, чтобы кадр всегда был закрыт
                if hug_x:
                    # есть overscan по X — можно ездить
                    min_x = W_target - fg_w   # максимально вправо
                    max_x = 0                 # максимально влево
                else:
                    # по X overscan нет — просто по центру
                    cx0 = (W_target - fg_w) / 2.0
                    min_x = max_x = cx0

                if hug_y:
                    # есть overscan по Y
                    min_y = H_target - fg_h   # максимально вниз
                    max_y = 0                 # максимально вверх
                else:
                    cy0 = (H_target - fg_h) / 2.0
                    min_y = max_y = cy0

                travel = 0.6  # доля от доступного диапазона
                cx = (min_x + max_x) / 2.0
                cy = (min_y + max_y) / 2.0

                def pick_span(min_v: float, max_v: float,
                              center: float, enable: bool, reverse: bool) -> tuple[float, float]:
                    """Отрезок, по которому будем ездить."""
                    if not enable or min_v == max_v:
                        return center, center
                    span = (max_v - min_v) * travel
                    if reverse:
                        return center + span / 2.0, center - span / 2.0
                    else:
                        return center - span / 2.0, center + span / 2.0

                use_x = hug_x  # двигаемся только по осям с overscan
                use_y = hug_y

                pattern = idx % 4  # чуть разнообразия: вправо, влево, вверх, вниз

                if pattern == 0:
                    start_x, end_x = pick_span(min_x, max_x, cx, use_x, False)
                    start_y = end_y = cy
                elif pattern == 1:
                    start_x, end_x = pick_span(min_x, max_x, cx, use_x, True)
                    start_y = end_y = cy
                elif pattern == 2:
                    start_x = end_x = cx
                    start_y, end_y = pick_span(min_y, max_y, cy, use_y, False)
                else:
                    start_x = end_x = cx
                    start_y, end_y = pick_span(min_y, max_y, cy, use_y, True)

                def alpha(t: float) -> float:
                    if sec_per <= 0:
                        return 0.0
                    x = min(max(t / sec_per, 0.0), 1.0)
                    # плавный ease-in-out
                    return 0.5 - 0.5 * math.cos(math.pi * x)

                def pos_func(t: float) -> tuple[float, float]:
                    a = alpha(t)
                    x = start_x + (end_x - start_x) * a
                    y = start_y + (end_y - start_y) * a
                    return x, y

                fg_moving = fg_clip.with_position(pos_func)

                clip = CompositeVideoClip(
                    [bg_clip, fg_moving],
                    size=(W_target, H_target),
                ).with_duration(sec_per)

        else:
            # --- все остальные режимы через fit_to_canvas ---
            offset = None
            if crop_offsets:
                offset = crop_offsets.get(str(p))

            frame = fit_to_canvas(
                p,
                size=(W, H),
                bg=bg,
                mode=fit_mode,
                fancy_bg=fancy_bg,
                offset=offset,
            )

            frame_arr = np.array(frame)
            clip = ImageClip(frame_arr).with_duration(sec_per)

            if motion == "zoom":
                # мягкий zoom для простого режима
                strength = 0.03

                # чуть разнообразия: чётный кадр — in, нечётный — out
                if idx % 2 == 0:
                    z0, z1 = 1.0, 1.0 + strength
                else:
                    z0, z1 = 1.0 + strength, 1.0

                def alpha_z(t: float) -> float:
                    if sec_per <= 0:
                        return 0.0
                    x = min(max(t / sec_per, 0.0), 1.0)
                    return 0.5 - 0.5 * math.cos(math.pi * x)

                def zoom_factor(t: float) -> float:
                    a = alpha_z(t)
                    return z0 + (z1 - z0) * a

                clip = clip.resized(new_size=zoom_factor)

        clips.append(clip)

        if progress_cb:
            progress_cb(idx, len(img_paths))

    if not clips:
        raise ValueError("Не удалось создать ни одного клипа")

    # ---- Переходы ----
    if transitions and len(clips) > 1:
        # длительность кроссфейда
        fade = min(sec_per * 0.3, 0.7)

        clips_with_fx: list[ImageClip] = []
        effect = CrossFadeIn(fade)

        for i, c in enumerate(clips):
            if i == 0:
                clips_with_fx.append(c)
            else:
                # плавно влетаем в каждый следующий кадр
                clips_with_fx.append(c.with_effects([effect.copy()]))

        # склейка
        video = concatenate_videoclips(
            clips_with_fx,
            method="compose",
            padding=-fade,  # клипы перекрываются на время фейда
        ).with_fps(int(fps))
    else:
        # старое поведение — просто склейка подряд
        video = concatenate_videoclips(
            clips,
            method="compose"
        ).with_fps(int(fps))

    # аудио (опционально)
    if audio:
        a = prepare_audio(str(audio), target_duration=video.duration, mode=audio_adjust)
        if a is not None:
            video = video.with_audio(a)

    out_path = Path(out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    video.write_videofile(
        str(out_path),
        codec="libx264",
        audio_codec="aac",
        fps=int(fps),
    )

    return str(out_path)