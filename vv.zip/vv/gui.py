from __future__ import annotations
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Dict, Tuple

from .pipeline import build_video, _collect_images
from .config import WIDTH, HEIGHT, FPS, SEC_PER, BG  # просто подтягиваем дефолты

CropOffsets = Dict[str, Tuple[float, float]]   # путь → (ox, oy) в [-1, 1]

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("image2video")

        # --- state ---
        self.image_inputs: list[str] = []
        self.audio_path: str | None = None
        self.out_path: str = "output/video.mp4"

        # --- vars ---
        self.sec_per = tk.DoubleVar(value=float(SEC_PER))
        self.fps     = tk.IntVar(value=int(FPS))
        self.bg      = tk.StringVar(value=str(BG))
        self.audio_mode = tk.StringVar(value="trim")
        self.transitions = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value="")

        # режим длительности: по кадру или по ролику
        self.duration_mode = tk.StringVar(value="per_frame")  # "per_frame" | "total"
        self.total_duration = tk.DoubleVar(value=0.0)

        # режим кадрирования и фон
        self.fit_mode   = tk.StringVar(value="cover")   # "fit" | "cover"

        # смещения кадра
        self.offset_x = tk.DoubleVar(value=0.0)
        self.offset_y = tk.DoubleVar(value=0.0)

        # реакция на смену режима: при "fit" отключаем слайдеры offset
        self.fit_mode.trace_add("write", self._update_offset_state)
        self.duration_mode.trace_add("write", self._update_duration_state)

        self.motion = tk.BooleanVar(value=False)

        # --- UI ---
        self._build_ui()

        # после построения UI — подгоняем размер
        self.update_idletasks()
        w = self.winfo_reqwidth()
        h = self.winfo_reqheight()
        self.minsize(w, h)
        self.geometry(f"{w}x{h}")

    def _build_ui(self):
        pad = dict(padx=10, pady=8)

        # Images
        frm_in = ttk.LabelFrame(self, text="Изображения")
        frm_in.pack(fill="x", **pad)

        self.lbl_imgs = ttk.Label(frm_in, text="Не выбрано")
        self.lbl_imgs.pack(side="left", padx=6)
        ttk.Button(frm_in, text="Папка…", command=self.pick_images_dir).pack(side="right")
        ttk.Button(frm_in, text="Файлы…", command=self.pick_images_files).pack(side="right", padx=6)

        # Audio
        frm_audio = ttk.LabelFrame(self, text="Аудио (опционально)")
        frm_audio.pack(fill="x", **pad)

        self.lbl_audio = ttk.Label(frm_audio, text="—")
        self.lbl_audio.pack(side="left", padx=6)
        ttk.Button(frm_audio, text="Выбрать…", command=self.pick_audio).pack(side="right")
        ttk.Button(frm_audio, text="Очистить", command=self.clear_audio).pack(side="right", padx=6)

        # Output
        frm_out = ttk.LabelFrame(self, text="Выходной файл")
        frm_out.pack(fill="x", **pad)

        self.ent_out = ttk.Entry(frm_out)
        self.ent_out.insert(0, self.out_path)
        self.ent_out.pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(frm_out, text="Сохранить как…", command=self.pick_out).pack(side="right")

        # Options
        frm_opts = ttk.LabelFrame(self, text="Параметры")
        frm_opts.pack(fill="x", **pad)

        # row_dur — режим длительности
        row_dur = ttk.Frame(frm_opts); row_dur.pack(fill="x", pady=4)

        # по кадру
        ttk.Radiobutton(
            row_dur,
            text="Кадр, сек",
            variable=self.duration_mode,
            value="per_frame",
        ).pack(side="left", padx=(6, 4))

        self.ent_sec_per = ttk.Entry(row_dur, textvariable=self.sec_per, width=8)
        self.ent_sec_per.pack(side="left")

        # по ролику
        ttk.Radiobutton(
            row_dur,
            text="Ролик, сек",
            variable=self.duration_mode,
            value="total",
        ).pack(side="left", padx=(16, 4))

        self.ent_total_duration = ttk.Entry(row_dur, textvariable=self.total_duration, width=8)
        self.ent_total_duration.pack(side="left")

        # row_fps — FPS + фон
        row_fps = ttk.Frame(frm_opts); row_fps.pack(fill="x", pady=4)
        ttk.Label(row_fps, text="FPS").pack(side="left", padx=(6,6))
        ttk.Combobox(
            row_fps,
            textvariable=self.fps,
            values=(24, 30, 60),
            width=5,
            state="readonly",
        ).pack(side="left")


        row2 = ttk.Frame(frm_opts); row2.pack(fill="x", pady=4)
        ttk.Label(row2, text="Аудио режим").pack(side="left", padx=6)
        ttk.Combobox(row2, textvariable=self.audio_mode, values=("trim","loop"), width=8, state="readonly").pack(side="left")
        ttk.Checkbutton(row2, text="Переходы (WIP)", variable=self.transitions).pack(side="left", padx=(16,0))

        row_mode = ttk.Frame(frm_opts); row_mode.pack(fill="x", pady=4)

        ttk.Label(row_mode, text="Кадрирование").pack(side="left", padx=6)
        ttk.Combobox(
            row_mode,
            textvariable=self.fit_mode,
            values=("fit", "cover"),
            width=8,
            state="readonly",
        ).pack(side="left")
        ttk.Checkbutton(row_mode, text="Лёгкое движение кадра", variable=self.motion).pack(side="left", padx=(16,0))


        self.frm_offsets = ttk.Frame(frm_opts)
        self.frm_offsets.pack(fill="x", pady=4)

        ttk.Label(self.frm_offsets, text="Смещение X (cover)").pack(side="left", padx=6)
        self.scale_offset_x = ttk.Scale(
            self.frm_offsets,
            from_=-100,
            to=100,
            orient="horizontal",
            variable=self.offset_x,
        )
        self.scale_offset_x.pack(side="left", fill="x", expand=True)

        ttk.Label(self.frm_offsets, text="Смещение Y (cover)").pack(side="left", padx=6)
        self.scale_offset_y = ttk.Scale(
            self.frm_offsets,
            from_=-100,
            to=100,
            orient="horizontal",
            variable=self.offset_y,
        )
        self.scale_offset_y.pack(side="left", fill="x", expand=True, padx=(0, 6))

        # сразу привести состояние слайдеров в соответствие с начальным режимом
        self._update_offset_state()
        self._update_duration_state()

        # Progress
        frm_prog = ttk.Frame(self); frm_prog.pack(fill="x", **pad)
        self.pbar = ttk.Progressbar(frm_prog, mode="determinate", maximum=100)
        self.pbar.pack(fill="x")
        self.lbl_status = ttk.Label(frm_prog, textvariable=self.status)
        self.lbl_status.pack(anchor="w", pady=4)

        # Actions
        frm_btn = ttk.Frame(self); frm_btn.pack(fill="x", **pad)
        ttk.Button(frm_btn, text="Собрать видео", command=self.start_render).pack(side="left")
        ttk.Button(frm_btn, text="Открыть папку выхода", command=self.open_out_dir).pack(side="right")

    # ---- pickers ----
    def pick_images_dir(self):
        d = filedialog.askdirectory(title="Папка с изображениями")
        if d:
            self.image_inputs = [d]
            self.lbl_imgs.config(text=f"Папка: {Path(d).name}")

    def pick_images_files(self):
        files = filedialog.askopenfilenames(
            title="Выбрать изображения",
            filetypes=[("Images","*.jpg *.jpeg *.png *.webp")]
        )
        if files:
            self.image_inputs = list(files)
            self.lbl_imgs.config(text=f"Файлов: {len(files)}")

    def pick_audio(self):
        f = filedialog.askopenfilename(
            title="Выбрать аудио",
            filetypes=[("Audio","*.mp3 *.wav")]
        )
        if f:
            self.audio_path = f
            self.lbl_audio.config(text=Path(f).name)

    def clear_audio(self):
        self.audio_path = None
        self.lbl_audio.config(text="—")

    def pick_out(self):
        f = filedialog.asksaveasfilename(
            title="Сохранить как",
            defaultextension=".mp4",
            filetypes=[("MP4","*.mp4")]
        )
        if f:
            self.out_path = f
            self.ent_out.delete(0, "end")
            self.ent_out.insert(0, f)

    def open_out_dir(self):
        p = Path(self.ent_out.get()).expanduser()
        d = p.parent
        if d.exists():
            import subprocess, platform
            if platform.system() == "Darwin":
                subprocess.run(["open", d])
            elif platform.system() == "Windows":
                subprocess.run(["explorer", str(d)])
            else:
                subprocess.run(["xdg-open", str(d)])

    def _update_offset_state(self, *args):
        """Обновить видимость слайдеров смещения и чекбокса fancy_bg."""
        mode = self.fit_mode.get()

        if mode == "cover":
            # показать, если вдруг спрятан
            if not self.frm_offsets.winfo_ismapped():
                self.frm_offsets.pack(fill="x", pady=4)
        else:
            # спрятать, если виден
            if self.frm_offsets.winfo_ismapped():
                self.frm_offsets.pack_forget()

    def _update_duration_state(self, *args):
        """Включать/отключать поля длительности в зависимости от режима."""
        mode = self.duration_mode.get()
        if mode == "per_frame":
            self.ent_sec_per.configure(state="normal")
            self.ent_total_duration.configure(state="disabled")
        else:
            self.ent_sec_per.configure(state="disabled")
            self.ent_total_duration.configure(state="normal")

    # ---- rendering ----
    def start_render(self):
        try:
            if not self.image_inputs:
                raise ValueError("Выбери изображения (папку или файлы).")
            self.out_path = self.ent_out.get().strip() or "output/video.mp4"
            Path(self.out_path).parent.mkdir(parents=True, exist_ok=True)
            self._set_running(True)
            self.status.set("Подготовка…")
            self.pbar.config(value=0, maximum=100)

            # прогресс — безопасно в GUI-поток через after()
            def progress_cb(current: int, total: int):
                self.after(0, self._on_progress, current, total)

            def worker():
                try:
                    # либо список, либо одна строка
                    imgs_input = self.image_inputs if len(self.image_inputs) > 1 else self.image_inputs[0]
                    # развернуть в реальные пути к файлам
                    img_paths = _collect_images(imgs_input)

                    # режимы кадрирования
                    fit_mode = self.fit_mode.get()

                    # нормализуем слайдеры из [-100, 100] в [-1.0, 1.0]
                    ox = max(-1.0, min(1.0, self.offset_x.get() / 100.0))
                    oy = max(-1.0, min(1.0, self.offset_y.get() / 100.0))

                    # offset имеет смысл только в cover
                    if fit_mode == "cover":
                        crop_offsets = {str(p): (ox, oy) for p in img_paths}
                        fancy_bg = False            # фон нам не нужен, кадр всё заполняет
                    else:
                        crop_offsets = None
                        fancy_bg = True             # всегда размазанный фон при fit

                    # режим длительности
                    duration_mode = self.duration_mode.get()
                    sec_per = float(self.sec_per.get())
                    total_duration = None

                    if duration_mode == "total":
                        total_duration = float(self.total_duration.get())

                    if self.motion.get():
                        motion = "kenburns"
                    else:
                        motion = "none"

                    result = build_video(
                        images=imgs_input,
                        out=self.out_path,
                        sec_per=float(self.sec_per.get()),
                        fps=int(self.fps.get()),
                        bg=self.bg.get(),  # технический, по сути не используется при fancy_bg
                        audio=self.audio_path,
                        transitions=bool(self.transitions.get()),
                        audio_adjust=self.audio_mode.get(),
                        progress_cb=progress_cb,
                        total_duration=total_duration,
                        fit_mode=fit_mode,
                        fancy_bg=fancy_bg,
                        crop_offsets=crop_offsets,
                        motion=motion,
                    )
                    self.after(0, self._on_done, result)
                except Exception as e:
                    self.after(0, self._on_error, e)

            threading.Thread(target=worker, daemon=True).start()

        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def _on_progress(self, current: int, total: int):
        # total приходит из pipeline при первом вызове — ставим максимум
        if total > 0:
            self.pbar.config(maximum=total)
        self.pbar.config(value=current)
        self.status.set(f"Обработка кадров: {current}/{total}")

    def _on_done(self, result_path: str):
        self._set_running(False)
        self.status.set("Готово.")
        messagebox.showinfo("Готово", f"Видео сохранено:\n{result_path}")

    def _on_error(self, err: Exception):
        self._set_running(False)
        self.status.set("Ошибка.")
        messagebox.showerror("Ошибка", str(err))

    def _set_running(self, running: bool):
        state = "disabled" if running else "normal"
        for w in self.winfo_children():
            if isinstance(w, (ttk.Frame, ttk.LabelFrame)):
                for c in w.winfo_children():
                    try: c.configure(state=state)
                    except tk.TclError: pass

def main():
    App().mainloop()

if __name__ == "__main__":
    main()